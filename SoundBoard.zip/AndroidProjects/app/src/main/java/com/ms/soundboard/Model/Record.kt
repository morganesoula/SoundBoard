package com.ms.soundboard.Model

data class Record(val title: String = "", val time: Long = 0L) { }
