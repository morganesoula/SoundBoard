package com.ms.soundboard.Adapter

import android.content.Context
import com.ms.soundboard.Model.Record

class RecordListAdapter(private val context: Context, private val records: List<Record>):
        RecyclerView.Adapter{
}